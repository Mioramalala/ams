<script>
$(function(){
	$('#fermer_mess_synth_vide_std').click(function(){
		$('#mess_vide_synthese_std').hide();
		$('#Int_Synthese_std').show();
	});
});
</script>

<div id="message_synth_vide_f">
<table width="500">
	<tr class="label" align="center" height="50">
		<td><img src="../cycle_achat_image/alerte.jpg" width="50" height="50" id="img_vide"/>Tous les champs doivent être remplis</td>
	</tr>
</table>
</div>
<div id="fermer_mess_synth_vide_std"><img src="../cycle_achat_image/Fermer.png" /></div>