<div id="message_vide_std">
	<table width="500">
		<tr style="height:20px">
			<td style="height:20px">
			</td>
		<tr>
			<td class="td_Contenue_Message" height="50" align="center">Vous devrez repondre à toutes les questions...</td>
		</tr>
		<tr>
			<td align="center">
				<input type="button" value="OK" class="bouton" id="message__Slide_vide_std">
			</td>
		</tr>
	</table>
</div>