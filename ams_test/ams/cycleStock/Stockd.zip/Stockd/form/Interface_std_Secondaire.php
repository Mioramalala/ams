<html>
<head>
<title>AMS | Cycle achat</title>

<script type="text/javascript" src="../cycleAchat/plugins/jquery.js"></script>
<script type="text/javascript" src="../cycleAchat/plugins/jquery.easyui.min.js"></script>

<!--link href="../cycle_achat_css/class.css" rel="stylesheet" type="text/css" /-->
<!--link href="cycleAchat/cycle_achat_css/div_fermer_quest_objectif_B.css" rel="stylesheet" type="text/css" />
<link href="cycleAchat/cycle_achat_css/class_b/class.css" rel="stylesheet" type="text/css" />
<link href="cycleAchat/cycle_achat_css/class_b/div.css" rel="stylesheet" type="text/css" /> 

<script type="text/javascript" src="cycleAchat/cycle_achat_js/cycle_achat_plugins/jquery.js"></script>
<script type="text/javascript" src="cycleAchat/cycle_achat_js/js.js"></script>
<script type="text/javascript" src="cycleAchat/cycle_achat_js/js_b.js"></script-->
<script>
$(document).ready(function() {
	// Formulaire draggable
	$('#Int_Synthese_std').draggable();
	$('#Question_std_152').draggable();
	$('#Question_std_153').draggable();
	$('#Question_std_154').draggable();
	$('#Question_std_155').draggable();
	$('#Question_std_156').draggable();
	$('#Question_std_157').draggable();
	$('#Question_std_158').draggable();
	$('#Question_std_159').draggable();
	$('#Question_std_160').draggable();
	$('#Question_std_161').draggable();
	$('#Question_std_162').draggable();
	$('#Question_std_163').draggable();
	$('#Question_std_164').draggable();
	$('#Question_std_165').draggable();
	$('#Question_std_166').draggable();
	$('#Question_std_167').draggable();
	$('#Question_std_168').draggable();
	$('#Question_std_169').draggable();
	$('#Question_std_170').draggable();
	$('#Question_std_171').draggable();
	$('#Question_std_172').draggable();
	$('#Question_std_173').draggable();
	$('#Question_std_174').draggable();
	$('#Question_std_175').draggable();
	$('#Question_std_176').draggable();
	$('#Question_std_177').draggable();
	$('#Question_std_178').draggable();
	$('#Question_std_179').draggable();
	$('#Question_std_180').draggable();
	// $('#int_conclusion_c_superviseur').draggable();
});
function openButtObjstd(){
	document.getElementById("int_std_Retour").disabled=false;
	document.getElementById("Int_std_Continuer").disabled=false;
	document.getElementById("Int_std_Synthese").disabled=false;
}
</script>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
</head>
<body>
<div id="fond_Sous_Titre" class="menu_Titre"><label class="marge_Titre">Evaluation du contrôle des fournisseurs</label><label class="margin_Code">Code : FC1</label>
</div>
<div id="fond_Question">
<table width="100%">
	<tr>
		<td class="titre" id="image_bleu" align="center"><!--label id="image_Bleu_A"> A. S’assurer que les séparations de fonctions sont suffisantes.</label-->
<label id="image_Bleu_b">D.Evaluation.</label>
		</td>
	</tr>
</table>
</div>
<!--**************************************Affichage de A.************************************************-->
<div id="interface_std" align="center"><?php include 'Interface_std.php'; ?></div>
<!--*****************************************************************************************************-->
</body>
</html>