
<html>
<head>
<title>AMS | Cycle achat</title>
<link href="cycleStock/Stockd/css/div.css" rel="stylesheet" type="text/css" />
<link href="cycleStock/Stockd/css/class.css" rel="stylesheet" type="text/css" />
<link href="cycleStock/Stockd/css/div_fermer_quest_objectif_std.css" rel="stylesheet" type="text/css" />
<!--link href="cycleAchat/cycle_achat_css/div.css" rel="stylesheet" type="text/css" />
<!--link href="../cycle_achat_css/class.css" rel="stylesheet" type="text/css" /-->
<!--link href="cycleAchat/cycle_achat_css/div_fermer_quest_objectif_B.css" rel="stylesheet" type="text/css" />
<link href="cycleAchat/cycle_achat_css/class_b/class.css" rel="stylesheet" type="text/css" />
<link href="cycleAchat/cycle_achat_css/class_b/div.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="cycleAchat/cycle_achat_js/cycle_achat_plugins/jquery.js"></script>
<script type="text/javascript" src="cycleAchat/cycle_achat_js/js.js"></script>
<script type="text/javascript" src="cycleAchat/cycle_achat_js/js_b.js"></script-->

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
</head>
<body>
<div id="fond_Sous_Titre" class="menu_Titre"><label class="marge_Titre">Evaluation du contrôle des fournisseurs</label> <label class="margin_Code">Code : FC1 </label>
</div>
<div id="fond_Question">
<table width="1250">
	<tr>
		<td class="titre" id="image_bleu" align="center"><!--label id="image_Bleu_A"> A. S’assurer que les séparations de fonctions sont suffisantes.</label-->
		
		</td>
	</tr>
</table>
</div>
<!--**************************************Affichage de A.************************************************-->
<div id="Interface_c_Sup" align="center"><?php include '../cycleAchat/cycle_achat_c/form/Interface_c_Superviseur.php'; ?></div>
<!--*****************************************************************************************************-->
</body>
</html>