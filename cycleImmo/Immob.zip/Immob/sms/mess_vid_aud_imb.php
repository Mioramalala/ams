<script>
$(function(){
	$('#message__Slide_vide_audit_imb').click(function(){
		$('#fancybox_imb').hide();
		$('#mess_vide_obj_imb').hide();
	});
});

</script>

<div id="message_vide_audit_imb ">
	<table width="500">
		<tr style="height:20px">
			<td style="height:20px">
			</td>
		</tr>
		<tr>
			<td class="td_Contenue_Message" height="50" align="center">Vous devez repondre à toutes les questions...</td>
		</tr>
		<tr>
			<td align="center">
				<input type="button" value="OK" class="bouton" id="message__Slide_vide_audit_imb">
			</td>
		</tr>
	</table>
</div>