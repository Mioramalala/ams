<div id="message_ouverture_quest_c">
<table width="500">
	<tr class="label" align="center" height="50">
		<td>Veuillez repondre aux questions suivantes et selectionner par oui, N/A ou non</td>
	</tr>
	<tr align="center" height="50">
		<td>
			<input type="button" class="bouton" value="Oui" id="valider_ouverture_c">			
		</td>
	</tr>
</table>
</div>