<html>
<head>
<title>AMS | Cycle achat</title>

<script type="text/javascript" src="../cycleAchat/plugins/jquery.js"></script>
<script type="text/javascript" src="../cycleAchat/plugins/jquery.easyui.min.js"></script>

<!--link href="../cycle_achat_css/class.css" rel="stylesheet" type="text/css" /-->
<!--link href="cycleAchat/cycle_achat_css/div_fermer_quest_objectif_B.css" rel="stylesheet" type="text/css" />
<link href="cycleAchat/cycle_achat_css/class_b/class.css" rel="stylesheet" type="text/css" />
<link href="cycleAchat/cycle_achat_css/class_b/div.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="cycleAchat/cycle_achat_js/cycle_achat_plugins/jquery.js"></script>
<script type="text/javascript" src="cycleAchat/cycle_achat_js/js.js"></script>
<script type="text/javascript" src="cycleAchat/cycle_achat_js/js_b.js"></script-->
<script>
$(document).ready(function() {
	// Formulaire draggable
	$('#Int_Synthese_imb').draggable();
	$('#Question_imb_70').draggable();
	$('#Question_imb_71').draggable();
	$('#Question_imb_72').draggable();
	$('#Question_imb_73').draggable();
	$('#Question_imb_74').draggable();
	$('#Question_imb_75').draggable();
	$('#Question_imb_76').draggable();
	$('#Question_imb_77').draggable();
	$('#Question_imb_78').draggable();
	$('#Question_imb_79').draggable();
	$('#Question_imb_80').draggable();
	$('#Question_imb_81').draggable();
	$('#Question_imb_82').draggable();
	$('#Question_imb_83').draggable();
	$('#Question_imb_84').draggable();
	$('#Question_imb_85').draggable();
	$('#Question_imb_86').draggable();
	$('#Question_imb_87').draggable();
	$('#Question_imb_88').draggable();
	$('#Question_imb_89').draggable();
	$('#Question_imb_90').draggable();
	$('#Question_imb_91').draggable();
	$('#Question_imb_92').draggable();
	// $('#int_conclusion_c_superviseur').draggable();
});
function openButtObjimb(){
	//document.getElementById("int_imb_Retour").disabled=false;
	document.getElementById("Int_imb_Continuer").disabled=false;
	document.getElementById("Int_imb_Synthese").disabled=false;
}
</script>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
</head>
<body>
<div id="fond_Sous_Titre" class="menu_Titre"><label class="marge_Titre">Evaluation du contrôle des fournisseurs</label><label class="margin_Code">Code : FC1</label>
</div>
<div id="fond_Question">
<table width="100%">
	<tr>
		<td class="titre" id="image_bleu" align="center"><!--label id="image_Bleu_A"> A. S’assurer que les séparations de fonctions sont suffisantes.</label-->
<label id="image_Bleu_b">B.Exhaustivité.</label>
		</td>
	</tr>
</table>
</div>
<!--**************************************Affichage de A.************************************************-->
<div id="interface_imb" align="center"><?php include 'Interface_imb.php'; ?></div>
<!--*****************************************************************************************************-->
</body>
</html>